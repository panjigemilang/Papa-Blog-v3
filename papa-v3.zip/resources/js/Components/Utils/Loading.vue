<template>
    <div
        class="absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2"
    >
        <i class="text-5xl fas fa-circle-notch fa-spin"></i>
    </div>
</template>

<script>
export default {
    name: "Loading"
};
</script>

<style></style>
